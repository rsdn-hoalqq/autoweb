<nav class="navbar navbar-inverse" id="mainmenu">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand text-color" href="#">TRANH THƯ PHÁP</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="actives text-color"><a href="/"><span class="glyphicon glyphicon-home text-color" aria-hidden="true"></span></a></li>
        <li><a href="#" class="text-color">Home</a></li>
        <li><a href="#" class="text-color">About</a></li>
        <li><a href="jligthBox.html" class="text-color">Gallery</a></li>
        <li><a href="#" class="text-color">Góc Thư Họa</a></li>
        <li><a href="slide.html" class="text-color">Slides</a></li>
      </ul>
      
    </div>
  </div>
</nav>