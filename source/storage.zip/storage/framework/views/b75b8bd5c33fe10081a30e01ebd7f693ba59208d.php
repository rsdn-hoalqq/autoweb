<div class="panel panel-default">
  <div class="panel-heading heading"><a href="/" class="headings" data-toggle="tooltip" title="Click để xem nhều hơn">VIDEO VẼ NGHỆ THUẬT</a></div>
  <div class="panel-body">
    <div class="row text-center">    
      <div class="col-sm-6">
        
        <div class="videos">
          <iframe class="videoClssBig" src="https://www.youtube.com/embed/tfUjUxUo1f0" frameborder="0" gesture="media" allowfullscreen></iframe>
        </div>
      </div>

      <div class="col-sm-6">
        <div class="row">
          <div class="col-sm-6">
            <iframe class="videoClss" src="https://www.youtube.com/embed/tfUjUxUo1f0" frameborder="0" gesture="media" allowfullscreen></iframe>
          </div>
          <div class="col-sm-6">
            <iframe class="videoClss" src="https://www.youtube.com/embed/tfUjUxUo1f0" frameborder="0" gesture="media" allowfullscreen></iframe>
          </div>

          <div class="col-sm-6">
            <iframe class="videoClss" src="https://www.youtube.com/embed/tfUjUxUo1f0" frameborder="0" gesture="media" allowfullscreen></iframe>
          </div>
          <div class="col-sm-6">
            <iframe class="videoClss" src="https://www.youtube.com/embed/tfUjUxUo1f0" frameborder="0" gesture="media" allowfullscreen></iframe>
          </div>

        </div>
      </div>

    </div>
  </div>
</div>