<div class="panel panel-default">
  <div class="panel-heading heading"><a href="/" class="headings">TRANH MỚI NHẤT</a></div>
  <div class="panel-body">
    <div class="row">

      <div class="col-sm-4 div-sm4">
        <div class="product-row">
          <div class="product-row-img">
            <a href="/">
              <img class="product-row-thumbnail" src="<?php echo e(asset('files/tranhthuphap/tranh1.jpg')); ?>" style="width:100%" alt="khăn lụa kết hoa tay">
            </a>
            <div class="product-row-price-hover"><a href="/products/khan-lua-ket-hoa-tay-5">
              <div class="product-row-note pull-left">Thông tin chi tiết sản phẩm</div>
              </a><a href="/products/khan-lua-ket-hoa-tay-5" class="product-row-btnbuy pull-right">Đặt hàng</a>
            </div>
          </div>
          <div>
            <p class="cls_font text-center">Thư pháp Trần Thế</p>
            <hr>
          </div>                
          <div class="product-row-info">        
            <div class="product-row-price pull-left"><br><span class="product-row-sale">350,000₫</span></div>
            <span class="product-row-counts pull-right"><i class="small">Còn</i>
            <br>
            <strong>1</strong></span>
            <div class="clearfix"></div>
          </div>
        </div>              
      </div>

    </div>
  </div>
</div>
      