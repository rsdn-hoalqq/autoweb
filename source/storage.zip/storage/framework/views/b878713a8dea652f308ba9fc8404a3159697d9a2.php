<div class="col-sm-2 sidenav hidden-xs">
  <div class="panel panel-default">
    <div class="panel-heading headings">DANH SÁCH SẢN PHẨM</div>
      <ul class="list-group">
        <li class="list-group-item"><a href="#" class="sty-a">Tranh Thủy mặc</a></li>
        <li class="list-group-item"><a href="" class="sty-a">Tranh Sơn Thủy</a></li>
        <li class="list-group-item"><a href="" class="sty-a">Tranh Hoa Điểu</a></li>
      </ul>
  </div>
  <div class="banner">
    <img src="public/files/banner-doc-2.jpg" alt="banner" style="width: 286px;">
  </div>
  <br>
  <div class="panel panel-default">
    <div class="panel-heading headings">THỐNG KÊ NGƯỜI DÙNG</div>
    <p>Số người đăng online: 100</p>
    <p>Số người đã đăng kí: 100</p>
  </div>
</div>