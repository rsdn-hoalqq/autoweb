<?php $__env->startSection('content'); ?>   
	<div class="panel panel-default">
		<div class="panel-heading headings">FORM CHỈNH SỮA CHUYÊN MỤC</div>
		<?php echo $__env->make('admin.common.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="panel-body">
			<?php echo $__env->make('admin.category.form',['btnAction'=>'Update','data'=>$data,'cates'=>$cates], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>