<div class="slides-wrapper">
	<div class="slides">      
	  	<div id="myCarousel" class="carousel slide" data-ride="carousel">
	      <div class="carousel-inner">
	        <div class="item active">
	          <img src="<?php echo e(asset('files/tranhthuphap/slide1.jpg')); ?>" class="img-responsive" style="width:100%" alt="Image">
	        </div>
			<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  	<div class="item">
			    	<img src="<?php echo e(asset('files/tranhthuphap/'.$value)); ?>" class="img-responsive" style="width:100%" alt="Image">
			  	</div>
		  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	      </div>

	      
	    </div>
	</div>

	<div class="item-slides">
	  <div class="img-row">
	  	<div class="panel panel-default heading-new">
	  		<div class="panel-heading heading heading-news"><a href="/" class="headings" data-toggle="tooltip" title="Click để xem nhều hơn">TIN MỚI</a></div>
		    <div class="row clss-news">
		    	<div class="col-sm-4">
		    		<div class="image-thumbnail">
		    			<img src="<?php echo e(asset('files/tranhthuphap/tranh1.jpg')); ?>" alt="" class="img-responsive">
		    		</div>
		    	</div>
		    	<div class="col-sm-8">
		    		<div class="caption">
		    			<div class="title-new">Ten tin tuc</div>
			            <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
			        </div>
		    	</div>
		    </div>

		    <div class="row clss-news">
		    	<div class="col-sm-4">
		    		<div class="image-thumbnail">
		    			<img src="<?php echo e(asset('files/tranhthuphap/tranh1.jpg')); ?>" alt="" class="img-responsive">
		    		</div>
		    	</div>
		    	<div class="col-sm-8">
		    		<div class="caption">
		    			<div class="title-new">Ten tin tuc</div>
			            <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
			        </div>
		    	</div>
		    </div>
		    <div class="row clss-news">
		    	<div class="col-sm-4">
		    		<div class="image-thumbnail">
		    			<img src="<?php echo e(asset('files/tranhthuphap/tranh1.jpg')); ?>" alt="" class="img-responsive">
		    		</div>
		    	</div>
		    	<div class="col-sm-8">
		    		<div class="caption">
		    			<div class="title-new">Ten tin tuc</div>
			            <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
			        </div>
		    	</div>
		    </div>		    
	  	</div>	  	
	  </div>
	</div>
</div>