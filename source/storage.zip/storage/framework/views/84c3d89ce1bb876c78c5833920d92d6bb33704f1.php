<!DOCTYPE html>
<html lang="en">
<head>
  	<title><?php echo $__env->yieldContent('title','Trang Chủ'); ?></title>
  	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<meta name="robots" content="index, follow">
	<meta name="title" content="">
	<meta name="author" content="">
	<meta name="copyright" content="">
	<meta name="description" content="Mo ta trang web" />
	<meta name="keywords" content="株式会社ピーエスシー,PSC,ピーエスシー, tag lien quan" />
	
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/front/mystyle.css')); ?>"></link>
</head>
<body>
	
	<?php $__env->startSection('header'); ?>
    <?php echo $__env->yieldSection(); ?>
    
    <?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->yieldSection(); ?>
    <div class="container-fluid bg-3">   
	  	<div class="row"><br>
	  	<?php echo $__env->yieldContent('content'); ?>  
	  	</div>
	</div>
	<script src="<?php echo e(asset('js/front.js')); ?>"></script>
</body>
</html>