<?php $__env->startSection('title', 'Page Title'); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('front.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('front.sidebar',['btnAction'=>'Thêm mới','cates'=>'param'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	
    <?php echo $__env->make('front.sidebarleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <div class="col-sm-10">
    	<?php $images = ['slide1.jpg','slide2.jpg','slide3.jpg'];?>
    	<?php echo $__env->make('front.slideshow',['images'=>$images], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    	
    	<?php echo $__env->make('front.videoblock', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    	
    	<?php echo $__env->make('front.product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    	
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>